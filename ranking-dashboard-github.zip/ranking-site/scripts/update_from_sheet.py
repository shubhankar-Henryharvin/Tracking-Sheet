"""Read the Nov 2026 revenue from the Google Sheet and rewrite index.html.

Needs env GOOGLE_SERVICE_ACCOUNT_JSON (service account key JSON). The sheet must be
shared with that service account's email (Viewer is enough).
"""
import datetime, json, os, re, sys
from google.oauth2 import service_account
from googleapiclient.discovery import build

MAIN = "12qltl4h1PbzzVPNxhi3sNVSFbHXJax_F5XOyyihTlUY"   # FY24-27 Mastersheet
KC = "1qk3qAaRS7SKvzsAhXWoMJOaBfOtT_OzztXoAH8l4tsM"     # FY22-25 Crestwood Mastersheet (KC & EW)

# Column index is relative to column E (E=0). name/rev/pct indexes; pct None = calculate from goal.
TABS = [
    (MAIN, "PP Monthly Q-3 (2026-27) Scoreboard",            dict(name=2, rev=5, pct=6, cat="PP", goal=None)),
    (MAIN, "PP Fellowship  Monthly Q- 3(26-27) Scoreboard",  dict(name=2, rev=6, pct=None, cat="Fellowship", goal=550000)),
    (MAIN, "DBA Monthly(Q-3 )(2026-27) Scoreboard",          dict(name=1, rev=4, pct=5, cat="DBA", goal=None)),
    (MAIN, "ECommerce Monthly Q- 3 (2026-27) Scoreboard",    dict(name=1, rev=3, pct=4, cat="ECOM", goal=None)),
    (MAIN, "ODS Monthly Q-3 (2026-27) Scoreboard",           dict(name=2, rev=5, pct=6, cat="ODS", goal=None)),
    (MAIN, "Recovery Monthly Q-3  (2026-27) Scoreboard",     dict(name=2, rev=5, pct=6, cat="Recovery", goal=None)),
    (KC,   "PP KC& EW Q-3 (2026-27) Scoreboard",             dict(name=3, rev=6, pct=None, cat="Eduwatts", goal=650000)),
]
# Sheet name -> dashboard name, where they differ
ALIAS = {
    "Himanshu PP Sales Himanshu PP Sales": "Himanshu PP Sales",
    ("Eduwatts", "Namita"): "Namita (Eduwatts)",
}

def norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())

def num(cell):
    if cell is None:
        return None
    s = str(cell).replace(",", "").replace("₹", "").replace("%", "").strip()
    try:
        return float(s)
    except ValueError:
        return None

def parse_tab(rows, cfg):
    out = []
    for row in rows:
        row = list(row) + [""] * 7
        name = re.sub(r"\s+", " ", str(row[cfg["name"]])).strip()
        rev = num(row[cfg["rev"]])
        if not name or rev is None:
            continue  # blank, header, or manager/total row
        if cfg["pct"] is not None:
            pct = num(row[cfg["pct"]])
        else:
            pct = None
        if pct is None:
            pct = rev / cfg["goal"] * 100 if cfg["goal"] else 0.0
        key = (cfg["cat"], name)
        name = ALIAS.get(key, ALIAS.get(name, name))
        out.append(dict(name=name, counsellor=name, category=cfg["cat"],
                        revenue=int(round(rev)), pct=round(pct, 2), goal=None))
    return out

def fetch(service, sheet_id, tab):
    rng = f"'{tab}'!E1:K400"
    return service.spreadsheets().values().get(spreadsheetId=sheet_id, range=rng).execute().get("values", [])

def main():
    creds = service_account.Credentials.from_service_account_info(
        json.loads(os.environ["GOOGLE_SERVICE_ACCOUNT_JSON"]),
        scopes=["https://www.googleapis.com/auth/spreadsheets.readonly"])
    service = build("sheets", "v4", credentials=creds, cache_discovery=False)

    fresh = []
    for sheet_id, tab, cfg in TABS:
        rows = parse_tab(fetch(service, sheet_id, tab), cfg)
        print(f"{cfg['cat']:10s} {len(rows):4d} rows  <- {tab}")
        if not rows:
            sys.exit(f"ABORT: no rows read from '{tab}' (tab renamed or layout changed?) - numbers not changed")
        fresh.extend(rows)

    path = "index.html"
    html = open(path, encoding="utf-8").read()
    m = re.search(r"const DATA = (\[.*?\]);", html, re.S)
    old = json.loads(m.group(1))
    old_by_key = {(r["category"], norm(r["counsellor"])): r for r in old}

    seen, merged = set(), []
    for f in fresh:
        k = (f["category"], norm(f["counsellor"]))
        seen.add(k)
        o = old_by_key.get(k)
        if o:
            o.update(revenue=f["revenue"], pct=f["pct"], counsellor=f["counsellor"])
            merged.append(o)
        else:
            merged.append(f)
            print("NEW row:", f["category"], f["counsellor"], f["revenue"])
    for r in old:
        if (r["category"], norm(r["counsellor"])) not in seen:
            print("NOT IN SHEET (kept as-is):", r["category"], r["counsellor"])
            merged.append(r)

    html = html[:m.start()] + "const DATA = " + json.dumps(merged, ensure_ascii=False) + ";" + html[m.end():]

    # Club 100 rows follow the DATA row they match
    by_name = {r["counsellor"]: r for r in merged}
    m = re.search(r"const CLUB = (\[.*?\]);", html, re.S)
    club = json.loads(m.group(1))
    for c in club:
        d = by_name.get(c.get("match"))
        if d:
            c.update(revenue=d["revenue"], pct=d["pct"], given=d["pct"])
    html = html[:m.start()] + "const CLUB = " + json.dumps(club, ensure_ascii=False) + ";" + html[m.end():]

    # Last-refresh timestamp shown on the page (IST)
    now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=5, minutes=30)))
    html = re.sub(r'const SNAP_AT = Date\.parse\("[^"]*"\);',
                  f'const SNAP_AT = Date.parse("{now.isoformat(timespec="seconds")}");', html)

    # Viewers' open pages reload every 15 minutes to pick up the newest publish
    if "AUTO_RELOAD" not in html:
        html = html.replace("setInterval(renderAge, 60000);",
                            "setInterval(renderAge, 60000); /* AUTO_RELOAD */ setInterval(function(){location.reload()}, 15*60*1000);", 1)

    open(path, "w", encoding="utf-8").write(html)
    print("rows:", len(merged), "| refreshed at", now.isoformat(timespec="seconds"))

if __name__ == "__main__":
    sys.exit(main())
