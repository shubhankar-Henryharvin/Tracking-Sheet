# Counsellor Ranking Dashboard (Nov 2026)

`index.html` is served by GitHub Pages. A GitHub Action reads the Google Sheet every 15 minutes,
rewrites the numbers in `index.html`, and commits when anything changed.

## One-time setup
1. Google Cloud: create a service account, create a JSON key for it.
2. Share both sheets (FY24-27 Mastersheet and FY22-25 Crestwood Mastersheet) with the service
   account's email address as **Viewer**.
3. GitHub repo → Settings → Secrets and variables → Actions → New secret
   `GOOGLE_SERVICE_ACCOUNT_JSON` = the full contents of the JSON key file.
4. Settings → Pages → Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
5. Actions tab → "Refresh dashboard from sheet" → Run workflow (first run).

## Notes
- Percentages: the sheet's own % column is used where it has one; Fellowship (÷ 550,000) and
  Eduwatts (÷ 650,000) are calculated.
- Rows missing from the sheet are kept with their last values and listed in the Action log.
- New names in the sheet are added automatically under their tab's department.
